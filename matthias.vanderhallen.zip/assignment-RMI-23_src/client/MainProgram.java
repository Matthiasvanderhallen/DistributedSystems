package client;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeoutException;

import rental.CarRentalCompany;
import rental.ICarRentalCompany;
import rental.Reservation;
import rental.ReservationException;
import agency.IManagerSession;
import agency.IReservationSession;
import agency.ISessionService;
import agency.NamingService;
import agency.SessionService;

public class MainProgram extends AbstractScriptedTripTest<IReservationSession,IManagerSession>{

	private ISessionService sessionService;
	
	public MainProgram(String scriptFile, String host, int port) throws RemoteException, NotBoundException {
		super(scriptFile);
		Registry registry = LocateRegistry.getRegistry(host, port);
		
		sessionService = (ISessionService) registry.lookup("SessionService");
	}
	
	/**
	 * This method starts the script.
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		//Start the SessionService.
		NamingService.main(null);
		SessionService.main(null);
		
		//create a new program running a certain script. It gets the script filename as an argument, as well as the location (host:port) of the registry.
		MainProgram program= new MainProgram("trips", "localhost", 1099);
		
		//load the CarRentalCompanies through a ManagerSession
		IManagerSession manager = program.getNewManagerSession("admin");
		program.registerCompany(manager, "Dockx", "dockx.csv");
		program.registerCompany(manager, "Hertz", "hertz.csv");
		program.closeManagerSession("admin");
		
		//Start the scripted test
		program.run();
	}
	
	/**
	 * Registers a company.
	 * @param manager
	 * @param companyName
	 * @param dataFile
	 * @throws NumberFormatException
	 * @throws ReservationException
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws TimeoutException
	 */
	private void registerCompany(IManagerSession manager, String companyName, String dataFile) throws NumberFormatException, ReservationException, IOException, IllegalStateException, TimeoutException{
		
		//Create a new CarRentalCompany, and create a remote stub through UnicastRemoteObjects exportObject method. 
		ICarRentalCompany company = new CarRentalCompany(companyName, dataFile);
		ICarRentalCompany stub =  (ICarRentalCompany)UnicastRemoteObject.exportObject(company, 0);
		
		//Ask the ManagerSession to register the company.
		manager.register(companyName, stub);
	}

	@Override
	protected IReservationSession getNewReservationSession(String name)
			throws Exception {
		return sessionService.createReservationSession(name);
	}

	@Override
	protected IManagerSession getNewManagerSession(String name) throws Exception {
		return sessionService.createManagerSession(name);
	}

	
	@Override
	protected void closeReservationSession(String name) throws Exception {
		sessionService.closeReservationSession(name);
		
	}

	@Override
	protected void closeManagerSession(String name) throws Exception {
		sessionService.closeManagerSession(name);
		
	}
	@Override
	protected void checkForAvailableCarTypes(IReservationSession session,
			Date start, Date end) throws Exception {
		session.getAvailableCarTypes(start, end);
	}

	@Override
	protected void addQuoteToSession(IReservationSession session, Date start,
			Date end, String carType, String carRentalName) throws Exception {
		session.createQuote(start, end, carType, carRentalName);
		
	}

	@Override
	protected void confirmQuotes(IReservationSession session) throws Exception {
		session.confirmQuotes();
	}

	@Override
	protected List<Reservation> getReservationsBy(IManagerSession ms,
			String clientName) throws Exception {
		return ms.getReservationsBy(clientName);
	}

	@Override
	protected int getReservationsForCarType(IManagerSession ms,
			String carRentalCompanyName, String carType) throws Exception {
		return ms.getNumberOfReservationsFor(carType, carRentalCompanyName);
	}

	@Override
	protected int getReservationsForCarType(IManagerSession ms, String carType)
			throws Exception {
		return ms.getNumberOfReservationsFor(carType);
	}



	

}
