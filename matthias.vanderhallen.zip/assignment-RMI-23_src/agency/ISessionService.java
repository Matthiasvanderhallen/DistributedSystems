package agency;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ISessionService extends Remote{

	/**
	 * Return the IManagerSession associated with the given name. If it doesn't exist, create a new one with the given name.
	 * @param name
	 * @return
	 * @throws RemoteException
	 */
	public abstract IManagerSession createManagerSession(String name) throws RemoteException;

	/**
	 * Return the IReservationSession associated with the given name. If it doesn't exist, create a new one with the given name.
	 * @param name
	 * @return
	 * @throws RemoteException
	 */
	public abstract IReservationSession createReservationSession(String name) throws RemoteException;

	
	/**
	 * Close the session associated with the given name.
	 * @param name
	 * @throws RemoteException
	 */
	public abstract void closeManagerSession(String name) throws RemoteException;

	/**
	 * Close the session associated with the given name.
	 * @param name
	 * @throws RemoteException
	 */
	public abstract void closeReservationSession(String name) throws RemoteException;

}