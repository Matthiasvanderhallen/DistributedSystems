package agency;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import rental.CarType;
import rental.ICarRentalCompany;
import rental.Quote;
import rental.Reservation;
import rental.ReservationConstraints;
import rental.ReservationException;

public class ReservationSession extends Session implements Remote, IReservationSession {
	private String name;
	private Collection<Quote> currentQuotes;
	private Registry namingService;
	
	public ReservationSession(String clientName, Registry namingService){
		this.name = clientName;
		this.namingService = namingService;
		currentQuotes = new LinkedList<Quote>();
	}
	
	@Override
	public Quote createQuote(Date start, Date end, String carType, String carRentalName) throws AccessException, RemoteException, NotBoundException, ReservationException, TimeoutException{
		setUsed();
		ICarRentalCompany carRentalCompany = (ICarRentalCompany) namingService.lookup(carRentalName);
		
		ReservationConstraints reservationConstraints = new ReservationConstraints(start, end, carType);
		Quote quote = carRentalCompany.createQuote(reservationConstraints, name);
		
		synchronized(namingService){
			currentQuotes.add(quote);
		}
		
		return quote;
	}
	
	@Override
	public Collection<Quote> getCurrentQuotes() throws TimeoutException{
		setUsed();
		synchronized(namingService){
			return new LinkedList<Quote>(currentQuotes);
		}
	}
	
	@Override
	public Collection<Reservation> confirmQuotes() throws AccessException, RemoteException, NotBoundException, ReservationException, TimeoutException{
		setUsed();
		synchronized(namingService){
			Map<Reservation, ICarRentalCompany> reservations = new HashMap<Reservation, ICarRentalCompany>();
			
			for(Quote quote: currentQuotes){
				ICarRentalCompany carRentalCompany = (ICarRentalCompany) namingService.lookup(quote.getRentalCompany());
				Reservation reservation;
				try {
					reservation = carRentalCompany.confirmQuote(quote);
				} catch (Exception e) {
					
					cancelReservations(reservations);
					
					throw new ReservationException("Reservation failed");
					
				}
				reservations.put(reservation, carRentalCompany);
			}
			
			return new HashSet<Reservation>(reservations.keySet());
		}
	}

	private void cancelReservations(Map<Reservation, ICarRentalCompany> reservations) throws TimeoutException {
		setUsed();
		for(Reservation reservation: reservations.keySet()){
			ICarRentalCompany carRentalCompany = reservations.get(reservation);
			try {
				carRentalCompany.cancelReservation(reservation);
			} catch (RemoteException e) {
				// Niet eenvoudig op te lossen in RMI
				System.err.println("Not able to cancel reservation " + reservation);
			}
		}
		
	}
	
	/**
     * Returns a collection with all the available CarTypes in the given period.
     * 
     * @param start
     * @param end
     * @return 
	 * @throws RemoteException 
	 * @throws AccessException 
	 * @throws TimeoutException 
     */
    @Override
	public Collection<CarType> getAvailableCarTypes(Date start, Date end) throws AccessException, RemoteException, TimeoutException {
    	setUsed();
        Collection<CarType> availableCars = new LinkedList<CarType>();
        
        for(String companyName:namingService.list()){
        	ICarRentalCompany company;
			try {
				company = (ICarRentalCompany) namingService.lookup(companyName);
				availableCars.addAll(company.getAvailableCarTypes(start, end));
			}catch (NotBoundException e) {}
        }
        return availableCars;
    }
}
