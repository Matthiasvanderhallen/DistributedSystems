package agency;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.TimeoutException;

import rental.CarType;
import rental.Quote;
import rental.Reservation;
import rental.ReservationException;

public interface IReservationSession extends Remote, ISession{

	
	public abstract Quote createQuote(Date start, Date end, String carType,
			String carRentalName) throws AccessException, RemoteException,
			NotBoundException, ReservationException, TimeoutException;

	public abstract Collection<Quote> getCurrentQuotes() throws RemoteException, TimeoutException;

	public abstract Collection<Reservation> confirmQuotes()
			throws AccessException, RemoteException, NotBoundException,
			ReservationException, TimeoutException;

	/**
	 * Returns a collection with all the available CarTypes in the given period.
	 * 
	 * @param start
	 * @param end
	 * @return 
	 * @throws RemoteException 
	 * @throws AccessException 
	 * @throws TimeoutException 
	 */
	public abstract Collection<CarType> getAvailableCarTypes(Date start,
			Date end) throws AccessException, RemoteException, TimeoutException;

}