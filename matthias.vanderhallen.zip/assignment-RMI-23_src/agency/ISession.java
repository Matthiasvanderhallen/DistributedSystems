package agency;

import java.rmi.RemoteException;
import java.util.concurrent.TimeoutException;

public interface ISession {
	public boolean isTimedOut() throws RemoteException;
	
	public void setUsed() throws TimeoutException, RemoteException;

}
