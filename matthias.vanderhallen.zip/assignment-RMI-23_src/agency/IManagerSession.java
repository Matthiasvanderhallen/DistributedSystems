package agency;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeoutException;

import rental.CarType;
import rental.ICarRentalCompany;
import rental.Reservation;

public interface IManagerSession extends Remote, ISession{

	/**
	 * Register a CarRentalCompany to the naming service
	 * @param carRentalCompanyName The name to register with
	 * @param carRentalCompany The company to register
	 * @throws AccessException
	 * @throws RemoteException
	 */
	public abstract void register(String carRentalCompanyName, ICarRentalCompany carRentalCompany)
			throws AccessException, RemoteException, TimeoutException;

	/**
	 * Unregister a CarRentalCompany from the naming service
	 * @param carRentalCompany the name to unregister
	 * @throws AccessException
	 * @throws RemoteException
	 */
	public abstract void unregister(String carRentalCompany)
			throws AccessException, RemoteException, TimeoutException;

	/**
	 * This method returns a collection with all possible CarTypes across all different CarRentalCompanies.
	 * 
	 * @return 
	 * @throws NotBoundException 
	 * @throws RemoteException 
	 * @throws AccessException 
	 */
	public abstract Collection<CarType> getCarTypes() throws AccessException,
			RemoteException, TimeoutException;

	/**
	 * Gets a list of the reservations made by a certain carRenter, across all different CarRentalCompanies.
	 * 
	 * @param carRenter
	 * @return 
	 * @throws RemoteException 
	 */
	public abstract List<Reservation> getReservationsBy(String carRenter)
			throws RemoteException, TimeoutException;

	/**
	 * Computes how many reservations were made for a certain carType at a certain CarRentalCompanies.
	 * 
	 * @param carType
	 * @param companyName
	 * @return 
	 * @throws RemoteException 
	 * @throws NotBoundException 
	 */

	public abstract int getNumberOfReservationsFor(String carType,
			String companyName) throws RemoteException, NotBoundException, TimeoutException;
	
	/**
	 * Computes how many reservations were made for a certain carType 
	 * @param carType
	 * @return
	 * @throws RemoteException
	 * @throws NotBoundException
	 */
	public abstract int getNumberOfReservationsFor(String carType) throws RemoteException, NotBoundException, TimeoutException;


}