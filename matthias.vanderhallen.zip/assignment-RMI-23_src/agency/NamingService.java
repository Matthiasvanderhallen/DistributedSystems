package agency;

import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class NamingService implements INamingService {
	private final int REGISTRY_CARRENTALCOMPANY_PORT = 23454;
	private Registry namingService;
	
	public NamingService() throws RemoteException{
		
		//Creates a new RMI Registry as a namingService for CarRentalCompanies. This runs on a special port, internally known within the agency.
		//Using this setup, it could even run on a separate server. (In which case this would just be a call to the .getRegistry(host, port) method.
		namingService =  LocateRegistry.createRegistry(REGISTRY_CARRENTALCOMPANY_PORT);
	}
	@Override
	public void bind(String arg0, Remote arg1) throws RemoteException,
			AlreadyBoundException, AccessException {
		namingService.bind(arg0, arg1);

	}

	@Override
	public String[] list() throws RemoteException, AccessException {
		return namingService.list();
	}

	@Override
	public Remote lookup(String arg0) throws RemoteException,
			NotBoundException, AccessException {
		return namingService.lookup(arg0);
	}

	@Override
	public void rebind(String arg0, Remote arg1) throws RemoteException,
			AccessException {
		namingService.rebind(arg0, arg1);
		//System.out.println("Rebinded of: " + arg0);

	}

	@Override
	public void unbind(String arg0) throws RemoteException, NotBoundException,
			AccessException {
		namingService.unbind(arg0);

	}
	
	/**
	 * Creates a new SessionService. This normally runs on the Agency server and is available through (in this case) an RMI Registry.
	 * 
	 * @param args
	 * @throws AccessException
	 * @throws RemoteException
	 */
	public static void main(String[] args) throws AccessException, RemoteException {
		//Allow everything
		System.setSecurityManager(null);
		
		//Export an object stub for binding with an RMI Registry. (In this case the local Registry).
		INamingService namingService = (INamingService) UnicastRemoteObject.exportObject(new NamingService(), 0);
		LocateRegistry.getRegistry().rebind("NamingService", namingService);
		//System.out.println("Everything executed");
	}

}
