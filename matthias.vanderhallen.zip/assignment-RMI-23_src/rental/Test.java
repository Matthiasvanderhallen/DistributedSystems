package rental;

import java.util.HashMap;
import java.util.Iterator;

public class Test {
 public static void main(String[] args) {
	HashMap<String, Integer> map = new HashMap<String, Integer>();
	map.put("a", 1);
	for(Iterator<String> it = map.keySet().iterator();it.hasNext();){
		it.next();
		it.remove();
	}
	System.out.println(map.size());
}
}
