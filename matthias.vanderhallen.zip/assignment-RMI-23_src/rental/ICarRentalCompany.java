package rental;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

public interface ICarRentalCompany extends Remote{

	/********
	 * NAME *
	 ********/

	public abstract String getName() throws RemoteException;

	/*************
	 * CAR TYPES *
	 *************/

	public abstract Collection<CarType> getAllCarTypes() throws RemoteException;

	public abstract CarType getCarType(String carTypeName)
			throws RemoteException;

	public abstract boolean isAvailable(String carTypeName, Date start, Date end)
			throws RemoteException;

	public abstract Set<CarType> getAvailableCarTypes(Date start, Date end)
			throws RemoteException;

	/****************
	 * RESERVATIONS *
	 ****************/

	public abstract Quote createQuote(ReservationConstraints constraints,
			String client) throws ReservationException, RemoteException;

	public abstract Reservation confirmQuote(Quote quote)
			throws ReservationException, RemoteException;

	public abstract void cancelReservation(Reservation res)
			throws RemoteException;

	/**
	 * Get the reservations for a particular client
	 * 
	 * @param 	clientName 
	 * 			name of the client
	 * @return 	list of Reservations for the given Client
	 * 
	 * @throws 	RemoteException
	 */
	public abstract List<Reservation> getReservationsBy(String clientName)
			throws RemoteException;

	/**
	 * Get the number of reservations for a particular car type.
	 * 
	 * @param 	carType 
	 * 			name of the car type
	 * @return 	number of reservations for the given car type
	 * 
	 * @throws 	RemoteException
	 */
	public abstract int getNumberOfReservationsForCarType(String carType)
			throws RemoteException;


}