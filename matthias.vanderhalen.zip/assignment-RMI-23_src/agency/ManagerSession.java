package agency;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import rental.CarRentalCompany;
import rental.CarType;
import rental.ICarRentalCompany;
import rental.Reservation;

public class ManagerSession extends Session implements Remote, IManagerSession {
	private final Registry namingService;
	
	public ManagerSession(Registry namingService){
		this.namingService = namingService;
	}
	
	@Override
	public void register(String carRentalCompanyName, ICarRentalCompany carRentalCompany) throws AccessException, RemoteException, TimeoutException{
		setUsed();
		namingService.rebind(carRentalCompanyName, carRentalCompany);
	}
	
	@Override
	public void unregister(String carRentalCompany) throws AccessException, RemoteException, TimeoutException{
		setUsed();
		try {
			namingService.unbind(carRentalCompany);
		} catch (NotBoundException e) {
			// Foute state waarin hij zat, maar nu wss terug juist dus geen klachten
		}
	}
	
	/**
     * This method returns a collection with all possible CarTypes across all different CarRentalCompanies.
     * 
     * @return 
	 * @throws NotBoundException 
	 * @throws RemoteException 
	 * @throws AccessException 
     */
    @Override
	public Collection<CarType> getCarTypes() throws AccessException, RemoteException , TimeoutException{
    	setUsed();
        Collection<CarType> types = new LinkedList<CarType>();
        
        for(String companyName:namingService.list()){
        	ICarRentalCompany company;
			try {
				company = (ICarRentalCompany) namingService.lookup(companyName);
				types.addAll(company.getAllCarTypes());
			} catch (NotBoundException e) {}
            
        }
        
        return types;
    }

    /**
     * Gets a list of the reservations made by a certain carRenter, across all different CarRentalCompanies.
     * 
     * @param carRenter
     * @return 
     * @throws RemoteException 
     */
    @Override
	public List<Reservation> getReservationsBy(String carRenter) throws RemoteException , TimeoutException{
    	setUsed();
        List<Reservation> reservations = new LinkedList<Reservation>();
        
        for(String companyName:namingService.list()){
        	ICarRentalCompany company;
			try {
				company = (ICarRentalCompany) namingService.lookup(companyName);
				reservations.addAll(company.getReservationsBy(carRenter));
			} catch (NotBoundException e) {}
        }
        return reservations;
    }

    /**
     * Computes how many reservations were made for a certain carType at a certain CarRentalCompanies.
     * 
     * @param carType
     * @param companyName
     * @return 
     * @throws RemoteException 
     * @throws NotBoundException 
     */
    
    @Override
	public int getNumberOfReservationsFor(String carType, String companyName) throws RemoteException, NotBoundException, TimeoutException{
    	setUsed();
    	ICarRentalCompany company = (ICarRentalCompany) namingService.lookup(companyName);
        
        return company.getNumberOfReservationsForCarType(carType);
    }
	@Override
	public int getNumberOfReservationsFor(String carType)
			throws RemoteException, NotBoundException, TimeoutException {
		setUsed();
		int result = 0;
		
		for(String companyName:namingService.list()){
			result += getNumberOfReservationsFor(carType, companyName);
		}
		
		return result;
	}
}
