package agency;

import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class SessionService implements ISessionService {
	private final static String HOST_OF_NAMING_SERVICE = "localhost";
	private Registry namingService;
	private Map <String, IManagerSession> managerSessions;
	private Map <String, IReservationSession> reservationSessions;
	
	
	public SessionService() throws RemoteException, NotBoundException{
		System.setSecurityManager(null);
		
		managerSessions = new HashMap<String, IManagerSession>();
		reservationSessions = new HashMap<String, IReservationSession>();
		
		//Creates a new RMI Registry as a namingService for CarRentalCompanies. This runs on a special port, internally known within the agency.
		//Using this setup, it could even run on a separate server. (In which case this would just be a call to the .getRegistry(host, port) method.
		Registry registry =  LocateRegistry.getRegistry(HOST_OF_NAMING_SERVICE);
		namingService = (Registry)registry.lookup("NamingService");
		createTimeOutScheduler();
	}

	/**
	 * Create a task that removes every timed out session at a fixed rate.
	 */
	private void createTimeOutScheduler() {
		TimerTask task = new TimerTask(){
			
			@Override
			public void run() {
				synchronized(managerSessions){
					for(Iterator<String> it = managerSessions.keySet().iterator(); it.hasNext();){
						String string = it.next();
						IManagerSession session = managerSessions.get(string);
						try {
							if(session.isTimedOut()){
								it.remove();
								System.out.println("Removed ManagerSession by timeout: " + string);
							}
						} catch (RemoteException e) {
							it.remove();
						}
					}
					
					
				}
				
				synchronized(reservationSessions){
					for(Iterator<String> it = reservationSessions.keySet().iterator(); it.hasNext();){
						String string = it.next();
						IReservationSession session = reservationSessions.get(string);
						try {
							if(session.isTimedOut()){
								it.remove();
								System.out.println("Removed ReservationSession by timeout: " + string);
							}
						} catch (RemoteException e) {
							it.remove();
						}
					}
					
				}
				
					
			}
			
		};
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(task, Session.getTimeOut()/2, Session.getTimeOut()/2);
	}
	
	/**
	 * Creates a new SessionService. This normally runs on the Agency server and is available through (in this case) an RMI Registry.
	 * 
	 * @param args
	 * @throws AccessException
	 * @throws RemoteException
	 * @throws NotBoundException 
	 */
	public static void main(String[] args) throws AccessException, RemoteException, NotBoundException {
		
		//Allow everything
		System.setSecurityManager(null);
		
		//Export an object stub for binding with an RMI Registry. (In this case the local Registry).
		ISessionService sessionService = (ISessionService) UnicastRemoteObject.exportObject(new SessionService(), 0);
		LocateRegistry.getRegistry().rebind("SessionService", sessionService);
	}
	
	@Override
	public IManagerSession createManagerSession(String name) throws RemoteException{
		if(!managerSessions.keySet().contains(name)){
			IManagerSession session = (IManagerSession) UnicastRemoteObject.exportObject(new ManagerSession(namingService), 0);
			managerSessions.put(name, session); 
		}
		return managerSessions.get(name);
	}
	
	@Override
	public IReservationSession createReservationSession(String name) throws RemoteException{
		if(!reservationSessions.keySet().contains(name)){
			IReservationSession session = (IReservationSession) UnicastRemoteObject.exportObject(new ReservationSession(name, namingService), 0);
			reservationSessions.put(name, session); 
		}
		return reservationSessions.get(name);
	}
	
	@Override
	public void closeManagerSession(String name){
		managerSessions.remove(name);
	}
	
	@Override
	public void closeReservationSession(String name){
		reservationSessions.remove(name);
	}
}
