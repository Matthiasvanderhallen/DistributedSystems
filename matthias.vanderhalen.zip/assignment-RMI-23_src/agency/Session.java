package agency;

import java.util.Date;
import java.util.concurrent.TimeoutException;

public class Session implements ISession {
	private final static long TIME_OUT_IN_SECONDS = 3600;
	
	private long lastAccess = new Date().getTime();
	
	
	@Override
	public boolean isTimedOut() {
		long now = new Date().getTime();
		return (now-TIME_OUT_IN_SECONDS) > lastAccess;
	}

	@Override
	public void setUsed() throws TimeoutException {
		if(isTimedOut())
			throw new TimeoutException();
		lastAccess = new Date().getTime();
	}

	public static long getTimeOut() {
		return TIME_OUT_IN_SECONDS;
	}

}
