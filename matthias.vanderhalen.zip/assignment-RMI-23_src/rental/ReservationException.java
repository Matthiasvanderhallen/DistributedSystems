package rental;

import java.io.Serializable;

// If a logical exception happens for example when you try to confirm a quote, you will get this exception 
// => so need to be serializable, it has to get to the client
public class ReservationException extends Exception implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -8159128964694199920L;

	public ReservationException(String string) {
        super(string);
    }
}